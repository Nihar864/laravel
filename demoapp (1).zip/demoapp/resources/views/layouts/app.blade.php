<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name', 'Laravel') }}</title>
    <!-- Include CSS and JS files -->
</head>
<body>
    <!-- Include header, navigation, etc. -->
    
    <div class="container">
        @yield('content')
    </div>

    <!-- Include footer, scripts, etc. -->
</body>
</html>
