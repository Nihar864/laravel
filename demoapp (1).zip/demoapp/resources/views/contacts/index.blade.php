<!-- resources/views/contacts/index.blade.php -->
<style>
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
  }

  td,
  th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
  }

  tr:nth-child(even) {
    background-color: #dddddd;
  }

  .btn.btn-primary.mb-3 {
    padding: 10px;
    border: 1px solid;
    margin: 20px;
    background: greenyellow;
    color: black;
    text-decoration: none;
  }
</style> @extends('layouts.app') @section('content') <h1>All Contacts</h1>
<a href="{{ route('contacts.create') }}" class="btn btn-primary mb-3">Create New Contact</a>
<ul class="list-group">
  <table>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Subject</th>
      <th>Description</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr> @foreach ($contacts as $contact) <tr>
      <td>
        <p>{{ $contact->name }}</p>
      </td>
      <td>
        <p>{{ $contact->email }}</p>
      </td>
      <td>
        <p>{{ $contact->subject }}</p>
      </td>
      <td>
        <p> {{ $contact->message }}</p>
      </td>
      <td>
        <a href="{{ route('contacts.edit', $contact->id) }}" class="btn btn-primary">Edit</a>
        </p>
      </td>
      <td>
        <form action="{{ route('contacts.destroy', $contact->id) }}" method="POST" class="d-inline"> @csrf @method('DELETE') <button type="submit" class="btn btn-danger">Delete</button>
        </form>
      </td>
    </tr> @endforeach
  </table> @endsection