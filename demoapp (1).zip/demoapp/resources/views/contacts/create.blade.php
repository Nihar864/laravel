<!-- resources/views/contacts/create.blade.php -->

@extends('layouts.app')

@section('content')
    <h1>Create New Contact</h1>
    <form action="{{ route('contacts.store') }}" method="POST">
        @csrf
        <table>
  <tr>
        <div class="form-group">
          <td>  <label for="name">Name</label></td>
          <td>  <input type="text" class="form-control" id="name" name="name"></td>
        </div>
</tr>  <tr>

        <div class="form-group">
        <td>    <label for="email">Email</label></td>
        <td>    <input type="email" class="form-control" id="email" name="email"></td>
        </div></tr>
        <tr>
    <div class="form-group">
    <td>    <label for="subject">Subject</label></td>
    <td>    <input type="text" class="form-control" id="subject" name="subject"></td>
        </div></tr>
        <tr>
  <div class="form-group">
  <td>   <label for="message">Message</label></td>
  <td>    <textarea class="form-control" id="message" name="message" rows="5"></textarea></td>
        </div></tr>
        <tr><td>
 <button type="submit" class="btn btn-primary">Create Contact</button></td></tr>
    </form>
@endsection
