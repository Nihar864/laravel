<!-- resources/views/contacts/show.blade.php -->

@extends('layouts.app')

@section('content')
    <h1>Contact Details</h1>
    
<table>
  <tr>
    <td>    <p><strong>Name:</strong> {{ $contact->name }}</p></td>
    <td>    <p><strong>Message:</strong> {{ $contact->message }}</p>
</td>
<td>    <p><strong>Email:</strong> {{ $contact->email }}</p>
</td>
<td>    <p><strong>Subject:</strong> {{ $contact->subject }}</p>
</td>
<td>     <a href="{{ route('contacts.edit', $contact->id) }}" class="btn btn-primary">Edit</a></p>
</td>
<td>     <form action="{{ route('contacts.destroy', $contact->id) }}" method="POST" class="d-inline">
    @csrf
    @method('DELETE')
    <button type="submit" class="btn btn-danger">Delete</button>
</form>
</td>
  </tr>
 
  
</table>
 
@endsection
