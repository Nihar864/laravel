@extends('layouts.app')

@section('content')
    <h1>Student Details</h1>

    <p><strong>Name:</strong> {{ $student->name }}</p>
    <p><strong>Email:</strong> {{ $student->email }}</p>
    <p><strong>Address:</strong> {{ $student->address }}</p>
    <p><strong>Phone Number:</strong> {{ $student->phone_number }}</p>
    <!-- Add other details here -->
@endsection
