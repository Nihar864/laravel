@extends('layouts.app')

@section('content')
    <h1>Create Student</h1>

    <form action="{{ route('students.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control">
        </div>
        <!-- Add other form fields here -->

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
@endsection
