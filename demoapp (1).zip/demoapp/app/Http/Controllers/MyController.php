<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MyModel;


class MyController extends Controller
{
    //
    public function insertForm()
    {
        return view('insert_form');
    }
    public function insertData(Request $request)
    {
        $data = new MyModel();
        $data->name = $request->input('name');
        $data->save();
        
        return redirect('/display');
    }


    public function displayData()
    {
        $data = MyModel::all();
        return view('display', compact('data'));
    }


}
