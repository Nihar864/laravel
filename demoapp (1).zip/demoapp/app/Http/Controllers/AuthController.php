<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    // Show the login form.
    public function showLoginForm()
    {
        return view('auth.login');
    }

    // Handle login form submission.
    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            // Authentication passed...
            return redirect()->intended('/');
        }

        return redirect()->back()->with('error', 'Invalid credentials');
    }

    // Show the registration form.
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    // Handle registration form submission.
    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);

        Auth::login($user);

        return redirect()->route('home');
    }

    // Logout the authenticated user.
    public function logout()
    {
        Auth::logout();
        return redirect()->route('login');
    }
}
