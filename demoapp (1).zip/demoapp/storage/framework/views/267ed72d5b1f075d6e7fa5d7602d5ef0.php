<!-- resources/views/insert_form.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Form</title>
</head>
<body>
    <h1>Insert Form</h1>
    <form method="POST" action="/insert">
        <?php echo csrf_field(); ?>
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name"><br><br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
<?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/insert_form.blade.php ENDPATH**/ ?>