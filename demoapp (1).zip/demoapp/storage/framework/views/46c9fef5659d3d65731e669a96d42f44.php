<div class="container">
        <h2>Edit Product</h2>
        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($product->name); ?>">
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea name="description" class="form-control"><?php echo e($product->description); ?></textarea>
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="text" name="price" class="form-control" value="<?php echo e($product->price); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update Product</button>
        </form>
    </div>

<?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/products/edit.blade.php ENDPATH**/ ?>