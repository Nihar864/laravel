<!-- resources/views/posts/create.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Create New Post</h1>
    <form action="<?php echo e(route('posts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" id="title" name="title">
        </div>
        <div class="form-group">
            <label for="body">Body</label>
            <textarea class="form-control" id="body" name="body" rows="6"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Create Post</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/posts/create.blade.php ENDPATH**/ ?>