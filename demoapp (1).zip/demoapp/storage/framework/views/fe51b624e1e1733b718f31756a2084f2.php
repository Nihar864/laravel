<div class="container">
        <h2><?php echo e($product->name); ?></h2>
        <p><strong>Description:</strong> <?php echo e($product->description); ?></p>
        <p><strong>Price:</strong> <?php echo e($product->price); ?></p>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Back</a>
    </div>
<?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/products/show.blade.php ENDPATH**/ ?>