<!-- resources/views/contacts/show.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Contact Details</h1>
    
<table>
  <tr>
    <td>    <p><strong>Name:</strong> <?php echo e($contact->name); ?></p></td>
    <td>    <p><strong>Message:</strong> <?php echo e($contact->message); ?></p>
</td>
<td>    <p><strong>Email:</strong> <?php echo e($contact->email); ?></p>
</td>
<td>    <p><strong>Subject:</strong> <?php echo e($contact->subject); ?></p>
</td>
<td>     <a href="<?php echo e(route('contacts.edit', $contact->id)); ?>" class="btn btn-primary">Edit</a></p>
</td>
<td>     <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="POST" class="d-inline">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger">Delete</button>
</form>
</td>
  </tr>
 
  
</table>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/contacts/show.blade.php ENDPATH**/ ?>