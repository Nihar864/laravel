<!-- resources/views/contacts/create.blade.php -->



<?php $__env->startSection('content'); ?>
    <h1>Create New Contact</h1>
    <form action="<?php echo e(route('contacts.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table>
  <tr>
        <div class="form-group">
          <td>  <label for="name">Name</label></td>
          <td>  <input type="text" class="form-control" id="name" name="name"></td>
        </div>
</tr>  <tr>

        <div class="form-group">
        <td>    <label for="email">Email</label></td>
        <td>    <input type="email" class="form-control" id="email" name="email"></td>
        </div></tr>
        <tr>
    <div class="form-group">
    <td>    <label for="subject">Subject</label></td>
    <td>    <input type="text" class="form-control" id="subject" name="subject"></td>
        </div></tr>
        <tr>
  <div class="form-group">
  <td>   <label for="message">Message</label></td>
  <td>    <textarea class="form-control" id="message" name="message" rows="5"></textarea></td>
        </div></tr>
        <tr><td>
 <button type="submit" class="btn btn-primary">Create Contact</button></td></tr>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/contacts/create.blade.php ENDPATH**/ ?>