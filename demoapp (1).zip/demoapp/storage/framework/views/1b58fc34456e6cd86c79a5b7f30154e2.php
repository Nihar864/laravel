<div class="container">
    	<h2>Products</h2>
    	<a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-2">Add Product</a>
    	<table class="table" border="2">
        	<thead>
            	<tr>
                	<th>Name</th>
                	<th>Description</th>
                	<th>Price</th>
                	<th>Action</th>
            	</tr>
        	</thead>
        	<tbody>
            	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            	<tr>
                	<td><?php echo e($product->name); ?></td>
                	<td><?php echo e($product->description); ?></td>
                	<td><?php echo e($product->price); ?></td>
                	<td>
                    	<a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-info btn-sm">View</a>
                    	<a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                    	<form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                        	<?php echo csrf_field(); ?>
                        	<?php echo method_field('DELETE'); ?>
                        	<button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?')">Delete</button>
                    	</form>
                	</td>
            	</tr>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	</tbody>
    	</table>
	</div>
<?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/products/index.blade.php ENDPATH**/ ?>