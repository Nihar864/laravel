<!-- resources/views/contacts/index.blade.php -->
<style>
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
  }

  td,
  th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
  }

  tr:nth-child(even) {
    background-color: #dddddd;
  }

  .btn.btn-primary.mb-3 {
    padding: 10px;
    border: 1px solid;
    margin: 20px;
    background: greenyellow;
    color: black;
    text-decoration: none;
  }
</style>  <?php $__env->startSection('content'); ?> <h1>All Contacts</h1>
<a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-primary mb-3">Create New Contact</a>
<ul class="list-group">
  <table>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Subject</th>
      <th>Description</th>
      <th>Edit</th>
      <th>Delete</th>
    </tr> <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <tr>
      <td>
        <p><?php echo e($contact->name); ?></p>
      </td>
      <td>
        <p><?php echo e($contact->email); ?></p>
      </td>
      <td>
        <p><?php echo e($contact->subject); ?></p>
      </td>
      <td>
        <p> <?php echo e($contact->message); ?></p>
      </td>
      <td>
        <a href="<?php echo e(route('contacts.edit', $contact->id)); ?>" class="btn btn-primary">Edit</a>
        </p>
      </td>
      <td>
        <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="POST" class="d-inline"> <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <button type="submit" class="btn btn-danger">Delete</button>
        </form>
      </td>
    </tr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/juiiee8487/LVCode/demoapp/resources/views/contacts/index.blade.php ENDPATH**/ ?>